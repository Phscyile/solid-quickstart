
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_portal-store.mts
import { getStore } from "@netlify/blobs";
var investigatorsStore = getStore("portal-investigators");
var casesStore = getStore("portal-cases");
var sessionsStore = getStore("portal-sessions");
var INVESTIGATOR_KEY_PREFIX = "investigator/";
var CASE_KEY_PREFIX = "case/";
var SESSION_KEY_PREFIX = "session/";
var SESSION_COOKIE = "portal_session";
var getInvestigator = async (badge) => investigatorsStore.get(`${INVESTIGATOR_KEY_PREFIX}${badge}`, { type: "json" });
var getSession = async (sessionId) => sessionsStore.get(`${SESSION_KEY_PREFIX}${sessionId}`, { type: "json" });
var listVisibleCases = async (badge) => {
  const { blobs } = await casesStore.list({ prefix: CASE_KEY_PREFIX });
  const visibleCases = [];
  for (const entry of blobs) {
    const caseRecord = await casesStore.get(entry.key, { type: "json" });
    if (!caseRecord) {
      continue;
    }
    const typedCase = caseRecord;
    const isAssigned = typedCase.assignedBadges.includes(badge);
    const isStartedByInvestigator = typedCase.startedByBadge === badge;
    if (isAssigned || isStartedByInvestigator) {
      visibleCases.push(typedCase);
    }
  }
  return visibleCases.sort((a, b) => a.createdAt < b.createdAt ? 1 : -1);
};

// netlify/functions/portal-me.mts
var json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { "content-type": "application/json; charset=utf-8" }
});
var getCookieFromHeader = (req, name) => {
  const cookieHeader = req.headers.get("cookie");
  if (!cookieHeader) {
    return null;
  }
  const parts = cookieHeader.split(";").map((part) => part.trim());
  const match = parts.find((part) => part.startsWith(`${name}=`));
  if (!match) {
    return null;
  }
  return decodeURIComponent(match.slice(name.length + 1));
};
var portal_me_default = async (req, context) => {
  if (req.method !== "GET") {
    return json({ error: "Method not allowed" }, 405);
  }
  const sessionId = context.cookies.get(SESSION_COOKIE) || getCookieFromHeader(req, SESSION_COOKIE);
  if (!sessionId) {
    return json({ authenticated: false }, 401);
  }
  const session = await getSession(sessionId);
  if (!session) {
    return json({ authenticated: false }, 401);
  }
  const investigator = await getInvestigator(session.badge);
  if (!investigator) {
    return json({ authenticated: false }, 401);
  }
  const cases = await listVisibleCases(investigator.badge);
  return json({
    authenticated: true,
    investigator: { badge: investigator.badge, name: investigator.name },
    cases
  });
};
var config = {
  path: "/api/portal/me"
};
export {
  config,
  portal_me_default as default
};
