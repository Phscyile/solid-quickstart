
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_portal-store.mts
import { getStore } from "@netlify/blobs";
import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
var investigatorsStore = getStore("portal-investigators");
var casesStore = getStore("portal-cases");
var sessionsStore = getStore("portal-sessions");
var INVESTIGATOR_KEY_PREFIX = "investigator/";
var CASE_KEY_PREFIX = "case/";
var SESSION_KEY_PREFIX = "session/";
var SESSION_COOKIE = "portal_session";
var isBadgeValid = (badge) => /^\d{1,10}$/.test(badge);
var getInvestigator = async (badge) => investigatorsStore.get(`${INVESTIGATOR_KEY_PREFIX}${badge}`, { type: "json" });
var getSession = async (sessionId) => sessionsStore.get(`${SESSION_KEY_PREFIX}${sessionId}`, { type: "json" });
var listVisibleCases = async (badge) => {
  const { blobs } = await casesStore.list({ prefix: CASE_KEY_PREFIX });
  const visibleCases = [];
  for (const entry of blobs) {
    const caseRecord = await casesStore.get(entry.key, { type: "json" });
    if (!caseRecord) {
      continue;
    }
    const typedCase = caseRecord;
    const isAssigned = typedCase.assignedBadges.includes(badge);
    const isStartedByInvestigator = typedCase.startedByBadge === badge;
    if (isAssigned || isStartedByInvestigator) {
      visibleCases.push(typedCase);
    }
  }
  return visibleCases.sort((a, b) => a.createdAt < b.createdAt ? 1 : -1);
};
var createCase = async ({
  title,
  summary,
  assignedBadges,
  startedByBadge
}) => {
  const caseRecord = {
    id: randomUUID(),
    title,
    summary,
    status: "active",
    assignedBadges,
    startedByBadge,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  await casesStore.setJSON(`${CASE_KEY_PREFIX}${caseRecord.id}`, caseRecord);
  return caseRecord;
};

// netlify/functions/portal-cases.mts
var json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { "content-type": "application/json; charset=utf-8" }
});
var getCookieFromHeader = (req, name) => {
  const cookieHeader = req.headers.get("cookie");
  if (!cookieHeader) {
    return null;
  }
  const parts = cookieHeader.split(";").map((part) => part.trim());
  const match = parts.find((part) => part.startsWith(`${name}=`));
  if (!match) {
    return null;
  }
  return decodeURIComponent(match.slice(name.length + 1));
};
var getCurrentInvestigator = async (req, context) => {
  const sessionId = context.cookies.get(SESSION_COOKIE) || getCookieFromHeader(req, SESSION_COOKIE);
  if (!sessionId) {
    return null;
  }
  const session = await getSession(sessionId);
  if (!session) {
    return null;
  }
  return getInvestigator(session.badge);
};
var portal_cases_default = async (req, context) => {
  const investigator = await getCurrentInvestigator(req, context);
  if (!investigator) {
    return json({ error: "Unauthorized" }, 401);
  }
  if (req.method === "GET") {
    const cases = await listVisibleCases(investigator.badge);
    return json({ cases });
  }
  if (req.method === "POST") {
    let body;
    try {
      body = await req.json();
    } catch {
      return json({ error: "Invalid JSON payload" }, 400);
    }
    const title = String(body?.title || "").trim().slice(0, 120);
    const summary = String(body?.summary || "").trim().slice(0, 800);
    const assignedBadges = Array.isArray(body?.assignedBadges) ? body.assignedBadges.map((value) => String(value || "").trim()).filter((value) => isBadgeValid(value)) : [];
    if (!title) {
      return json({ error: "Case title is required." }, 400);
    }
    const normalizedAssignedBadges = [...new Set(assignedBadges)];
    const caseRecord = await createCase({
      title,
      summary,
      assignedBadges: normalizedAssignedBadges,
      startedByBadge: investigator.badge
    });
    return json({ case: caseRecord }, 201);
  }
  return json({ error: "Method not allowed" }, 405);
};
var config = {
  path: "/api/portal/cases"
};
export {
  config,
  portal_cases_default as default
};
