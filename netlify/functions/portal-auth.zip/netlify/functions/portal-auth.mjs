
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_portal-store.mts
import { getStore } from "@netlify/blobs";
import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
var investigatorsStore = getStore("portal-investigators");
var casesStore = getStore("portal-cases");
var sessionsStore = getStore("portal-sessions");
var INVESTIGATOR_KEY_PREFIX = "investigator/";
var SESSION_KEY_PREFIX = "session/";
var SESSION_COOKIE = "portal_session";
var isBadgeValid = (badge) => /^\d{1,10}$/.test(badge);
var isPasswordValidForBadge = (badge, password) => {
  const pinLength = Number.parseInt(process.env.PORTAL_PIN_LENGTH || "4", 10);
  const exactPin = new RegExp(`^\\d{${Math.max(1, pinLength)}}$`);
  return password === badge || exactPin.test(password);
};
var hashPassword = (password) => createHash("sha256").update(password).digest("hex");
var verifyPassword = (storedHash, password) => {
  const candidateHash = hashPassword(password);
  const a = Buffer.from(storedHash);
  const b = Buffer.from(candidateHash);
  if (a.length !== b.length) {
    return false;
  }
  return timingSafeEqual(a, b);
};
var getInvestigator = async (badge) => investigatorsStore.get(`${INVESTIGATOR_KEY_PREFIX}${badge}`, { type: "json" });
var createInvestigator = async ({
  badge,
  name,
  password
}) => {
  const record = {
    badge,
    name,
    passwordHash: hashPassword(password),
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  await investigatorsStore.setJSON(`${INVESTIGATOR_KEY_PREFIX}${badge}`, record);
  return record;
};
var createSession = async (badge) => {
  const sessionId = randomUUID();
  const record = { badge, createdAt: (/* @__PURE__ */ new Date()).toISOString() };
  await sessionsStore.setJSON(`${SESSION_KEY_PREFIX}${sessionId}`, record);
  return sessionId;
};
var deleteSession = async (sessionId) => sessionsStore.delete(`${SESSION_KEY_PREFIX}${sessionId}`);

// netlify/functions/portal-auth.mts
var json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { "content-type": "application/json; charset=utf-8" }
});
var getCookieFromHeader = (req, name) => {
  const cookieHeader = req.headers.get("cookie");
  if (!cookieHeader) {
    return null;
  }
  const parts = cookieHeader.split(";").map((part) => part.trim());
  const match = parts.find((part) => part.startsWith(`${name}=`));
  if (!match) {
    return null;
  }
  return decodeURIComponent(match.slice(name.length + 1));
};
var portal_auth_default = async (req, context) => {
  if (req.method !== "POST") {
    return json({ error: "Method not allowed" }, 405);
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON payload" }, 400);
  }
  const action = String(body?.action || "").trim();
  const badge = String(body?.badge || "").trim();
  const password = String(body?.password || "").trim();
  if (action === "logout") {
    const existingSessionId = context.cookies.get(SESSION_COOKIE) || getCookieFromHeader(req, SESSION_COOKIE);
    if (existingSessionId) {
      await deleteSession(existingSessionId);
    }
    context.cookies.delete(SESSION_COOKIE);
    return json({ ok: true });
  }
  if (!isBadgeValid(badge)) {
    return json({ error: "Badge number must be numeric." }, 400);
  }
  if (!isPasswordValidForBadge(badge, password)) {
    return json(
      { error: "Password must match the badge number or a configured numeric pin length." },
      400
    );
  }
  if (action === "signup") {
    const existingInvestigator = await getInvestigator(badge);
    if (existingInvestigator) {
      return json({ error: "Badge already has an account." }, 409);
    }
    const nameInput = String(body?.name || "").trim();
    const name = nameInput.length > 0 ? nameInput.slice(0, 80) : `Investigator ${badge}`;
    const investigator = await createInvestigator({ badge, name, password });
    const sessionId = await createSession(investigator.badge);
    context.cookies.set({
      name: SESSION_COOKIE,
      value: sessionId,
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
      httpOnly: true,
      sameSite: "Lax",
      secure: new URL(req.url).protocol === "https:"
    });
    return json({
      investigator: {
        badge: investigator.badge,
        name: investigator.name
      }
    });
  }
  if (action === "login") {
    const investigator = await getInvestigator(badge);
    if (!investigator || !verifyPassword(investigator.passwordHash, password)) {
      return json({ error: "Invalid badge/password." }, 401);
    }
    const sessionId = await createSession(investigator.badge);
    context.cookies.set({
      name: SESSION_COOKIE,
      value: sessionId,
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
      httpOnly: true,
      sameSite: "Lax",
      secure: new URL(req.url).protocol === "https:"
    });
    return json({
      investigator: {
        badge: investigator.badge,
        name: investigator.name
      }
    });
  }
  return json({ error: "Unsupported action." }, 400);
};
var config = {
  path: "/api/portal/auth"
};
export {
  config,
  portal_auth_default as default
};
